//
//  StocksMO+CoreDataClass.swift
//  StocksApp
//
//  Created by  E.Tratotul on 30.11.2019.
//  Copyright © 2019  E.Tratotul. All rights reserved.
//
//

import Foundation
import CoreData

@objc(StocksMO)
public class StocksMO: NSManagedObject {

}
