//
//  SearchStockResponce.swift
//  StocksApp
//
//  Created by  E.Tratotul on 07.12.2019.
//  Copyright © 2019  E.Tratotul. All rights reserved.
//

import Foundation

final class SearchStockResponce: Codable{
    let bestMatches: [SearchStockModel]    
}
